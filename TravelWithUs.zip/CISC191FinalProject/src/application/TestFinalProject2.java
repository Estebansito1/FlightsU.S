package application;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestFinalProject2
{

	@Test
	void test()
	{ 
		System.out.print("Testing Branch");
	}

}

