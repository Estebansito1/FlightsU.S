package application;

public class Main {
	public static void main(String[] args) {
		Traveler traveler = new Traveler("John Kelley", 27);
		
		MealOptions meal1 = new MealOptions(traveler, "Steak and potatoes", 560, 7.65);
		MealOptions meal2 = new MealOptions(traveler, "Grill Salmon and vegetables", 450, 10.99);
		MealOptions meal3 = new MealOptions(traveler, "Vegetarian pasta primavera", 380, 8.50);

		System.out.println("Meal 1: " + meal1.getMealName() + ", Calories: " + meal1.getMealCalories() + ", price: $" + meal1.getMealPrice());
		System.out.println("Meal 2: " + meal2.getMealName() + ", Calories: " + meal2.getMealCalories() + ", price: $" + meal2.getMealPrice());
		System.out.println("Meal 3: " + meal3.getMealName() + ", Calories: " + meal3.getMealCalories() + ", price: $" + meal3.getMealPrice());


	}
	
}